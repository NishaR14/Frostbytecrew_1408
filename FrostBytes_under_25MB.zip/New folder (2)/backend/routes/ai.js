

const express = require('express');
const router = express.Router();

/**
 * AI CHAT ROUTE
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages } = req.body;

    // ✅ Validate messages
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({
        reply: "I'm here with you. Can you tell me more?"
      });
    }

    // 🔍 DEBUG: see what frontend sends
    console.log("🔥 AI MESSAGES RECEIVED:", messages);

    const response = await fetch(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'llama-3.1-8b-instant',
          messages: messages,
          temperature: 0.8,
          max_tokens: 200
        })
      }
    );

    const data = await response.json();

    console.log("🤖 GROQ RAW RESPONSE:", data);

    const reply =
      data?.choices?.[0]?.message?.content?.trim() ||
      "I'm here with you. Can you tell me a bit more?";

    res.json({ reply });

  } catch (err) {
    console.error('❌ Groq backend error:', err);
    res.json({
      reply: "I'm here with you. Would you like to share more?"
    });
  }
});

module.exports = router;
