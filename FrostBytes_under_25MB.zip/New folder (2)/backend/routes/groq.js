const express = require('express');
const router = express.Router();

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

// Health endpoint - checks that key exists
router.get('/health', (req, res) => {
  const key = process.env.GROQ_API_KEY;
  if (!key) return res.status(503).json({ connected: false, message: 'API key not configured' });
  return res.json({ connected: true });
});

// Proxy endpoint: forwards body to Groq and returns the response
router.post('/', async (req, res) => {
  const key = process.env.GROQ_API_KEY;
  if (!key) return res.status(503).json({ error: 'API key not configured' });

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key}`
      },
      body: JSON.stringify(req.body)
    });

    const text = await response.text();
    // Try to parse JSON; if not JSON, send text
    try {
      const data = JSON.parse(text);
      return res.status(response.status).json(data);
    } catch (e) {
      return res.status(response.status).send(text);
    }
  } catch (err) {
    console.error('Error proxying to Groq:', err);
    return res.status(502).json({ error: 'Failed to reach Groq API', details: err.message });
  }
});

module.exports = router;