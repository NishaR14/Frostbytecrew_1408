const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { firestore, admin } = require('../config/firebaseAdmin');

// POST /api/firebase/test
// Writes a small test document under users/{uid}/system_tests/{randomId}
router.post('/test', authMiddleware, async (req, res) => {
  try {
    if (!firestore) return res.status(500).json({ error: 'Firestore not initialized. Add service account or set GOOGLE_APPLICATION_CREDENTIALS.' });

    const uid = String(req.user._id);
    const docRef = firestore
      .collection('users')
      .doc(uid)
      .collection('system_tests')
      .doc();

    await docRef.set({
      ok: true,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      note: 'test write from /api/firebase/test'
    });

    res.json({ success: true, path: `${docRef.path}` });
  } catch (error) {
    console.error('Firebase test write failed:', error);
    res.status(500).json({ error: 'Firebase test write failed', details: error.message });
  }
});

// POST /api/firebase/verify-id-token
// Verifies a Firebase ID token (useful if you add client sign-in later)
router.post('/verify-id-token', async (req, res) => {
  const { idToken } = req.body;
  if (!idToken) return res.status(400).json({ error: 'idToken is required' });

  try {
    const decoded = await admin.auth().verifyIdToken(idToken);
    res.json({ uid: decoded.uid, email: decoded.email, decoded });
  } catch (error) {
    console.error('ID token verification failed:', error);
    res.status(401).json({ error: 'ID token verification failed', details: error.message });
  }
});

module.exports = router;