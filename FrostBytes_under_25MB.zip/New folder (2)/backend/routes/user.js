const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Mood = require('../models/Mood');
const Journal = require('../models/Journal');
const Meditation = require('../models/Meditation');
const { authMiddleware } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

// Apply auth middleware to all routes
router.use(authMiddleware);

// @route   GET /api/user/profile
// @desc    Get user profile information
// @access  Private
router.get('/profile', async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password')
      .lean();

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching user profile' });
  }
});

// @route   PUT /api/user/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', [
  body('username')
    .optional()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters'),
  body('email')
    .optional()
    .isEmail()
    .withMessage('Please enter a valid email'),
  body('preferences.theme')
    .optional()
    .isIn(['light', 'dark', 'auto'])
    .withMessage('Theme must be light, dark, or auto'),
  body('preferences.notifications')
    .optional()
    .isBoolean()
    .withMessage('Notifications must be true or false'),
  body('preferences.dailyReminder')
    .optional()
    .isBoolean()
    .withMessage('Daily reminder must be true or false')
], async (req, res) => {
  try {
    // Prevent guest users from updating profile
    if (req.user.isGuest) {
      return res.status(403).json({ 
        error: 'Guest users cannot update profile information' 
      });
    }

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, email, preferences } = req.body;
    const updateData = {};

    if (username !== undefined) updateData.username = username;
    if (email !== undefined) updateData.email = email;
    if (preferences !== undefined) updateData.preferences = preferences;

    // Check if new username or email already exists
    if (username || email) {
      const existingUser = await User.findOne({
        $and: [
          { _id: { $ne: req.user._id } },
          {
            $or: [
              ...(username ? [{ username }] : []),
              ...(email ? [{ email }] : [])
            ]
          }
        ]
      });

      if (existingUser) {
        return res.status(400).json({ 
          error: 'Username or email already exists' 
        });
      }
    }

    const updatedUser = await User.findByIdAndUpdate(
      req.user._id,
      updateData,
      { new: true, runValidators: true }
    ).select('-password');

    res.json({
      message: 'Profile updated successfully',
      user: updatedUser
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error updating profile' });
  }
});

// @route   PUT /api/user/password
// @desc    Update user password
// @access  Private
router.put('/password', [
  body('currentPassword')
    .notEmpty()
    .withMessage('Current password is required'),
  body('newPassword')
    .isLength({ min: 6 })
    .withMessage('New password must be at least 6 characters long')
], async (req, res) => {
  try {
    // Prevent guest users from changing password
    if (req.user.isGuest) {
      return res.status(403).json({ 
        error: 'Guest users cannot change password' 
      });
    }

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { currentPassword, newPassword } = req.body;

    // Get fresh user instance with password
    const user = await User.findById(req.user._id);
    
    // Verify current password
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ 
        error: 'Current password is incorrect' 
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error updating password' });
  }
});

// @route   GET /api/user/dashboard
// @desc    Get dashboard data (summary stats)
// @access  Private
router.get('/dashboard', async (req, res) => {
  try {
    const userId = req.user._id;
    
    // Get today's date range
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Get mood for today
    const todayMood = await Mood.findOne({
      user: userId,
      date: { $gte: today, $lt: tomorrow }
    }).lean();

    // Get recent journal entries
    const recentJournals = await Journal.find({ user: userId })
      .sort({ date: -1 })
      .limit(3)
      .select('content mood date')
      .lean();

    // Get mood history for the last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const weeklyMoods = await Mood.find({
      user: userId,
      date: { $gte: sevenDaysAgo }
    })
    .sort({ date: 1 })
    .select('mood intensity date')
    .lean();

    // Get meditation stats
    const meditationStats = await Meditation.aggregate([
      {
        $match: { user: userId }
      },
      {
        $group: {
          _id: null,
          totalSessions: { $sum: 1 },
          totalDuration: { $sum: '$duration' },
          avgDuration: { $avg: '$duration' }
        }
      }
    ]);

    // Format weekly moods for chart
    const moodChartData = weeklyMoods.map(mood => ({
      date: new Date(mood.date).toLocaleDateString('en-US', { weekday: 'short' }),
      mood: mood.mood,
      intensity: mood.intensity
    }));

    // Get user stats
    const user = await User.findById(userId).select('stats').lean();

    res.json({
      todayMood,
      recentJournals,
      moodChart: moodChartData,
      meditation: meditationStats[0] || {
        totalSessions: 0,
        totalDuration: 0,
        avgDuration: 0
      },
      stats: user.stats,
      insights: generateInsights(weeklyMoods, recentJournals)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching dashboard data' });
  }
});

// @route   GET /api/user/stats
// @desc    Get comprehensive user statistics
// @access  Private
router.get('/stats', async (req, res) => {
  try {
    const userId = req.user._id;
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Get all stats in parallel for better performance
    const [
      moodStats,
      journalStats,
      meditationStats,
      streakData
    ] = await Promise.all([
      // Mood statistics
      Mood.aggregate([
        { $match: { user: userId } },
        {
          $group: {
            _id: null,
            totalEntries: { $sum: 1 },
            avgIntensity: { $avg: '$intensity' },
            moodDistribution: {
              $push: {
                mood: '$mood',
                intensity: '$intensity'
              }
            }
          }
        }
      ]),

      // Journal statistics
      Journal.aggregate([
        { $match: { user: userId } },
        {
          $group: {
            _id: null,
            totalEntries: { $sum: 1 },
            totalWords: { $sum: '$wordCount' },
            avgWordCount: { $avg: '$wordCount' }
          }
        }
      ]),

      // Meditation statistics
      Meditation.aggregate([
        { $match: { user: userId } },
        {
          $group: {
            _id: null,
            totalSessions: { $sum: 1 },
            totalMinutes: { $sum: '$duration' },
            avgDuration: { $avg: '$duration' }
          }
        }
      ]),

      // Calculate streak
      calculateStreak(userId)
    ]);

    // Process mood distribution
    const moodDistribution = {};
    if (moodStats[0]?.moodDistribution) {
      moodStats[0].moodDistribution.forEach(item => {
        if (!moodDistribution[item.mood]) {
          moodDistribution[item.mood] = { count: 0, totalIntensity: 0 };
        }
        moodDistribution[item.mood].count++;
        moodDistribution[item.mood].totalIntensity += item.intensity;
      });

      // Calculate averages
      Object.keys(moodDistribution).forEach(mood => {
        moodDistribution[mood].avgIntensity = 
          moodDistribution[mood].totalIntensity / moodDistribution[mood].count;
      });
    }

    // Get activity trend for last 30 days
    const activityTrend = await Mood.aggregate([
      {
        $match: {
          user: userId,
          date: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$date' }
          },
          activity: { $sum: 1 }
        }
      },
      { $sort: { '_id': 1 } }
    ]);

    res.json({
      mood: {
        totalEntries: moodStats[0]?.totalEntries || 0,
        avgIntensity: moodStats[0]?.avgIntensity || 0,
        distribution: moodDistribution
      },
      journal: {
        totalEntries: journalStats[0]?.totalEntries || 0,
        totalWords: journalStats[0]?.totalWords || 0,
        avgWordCount: journalStats[0]?.avgWordCount || 0
      },
      meditation: {
        totalSessions: meditationStats[0]?.totalSessions || 0,
        totalMinutes: meditationStats[0]?.totalMinutes || 0,
        avgDuration: meditationStats[0]?.avgDuration || 0
      },
      streaks: streakData,
      activityTrend: activityTrend.map(item => ({
        date: item._id,
        activity: item.activity
      })),
      overall: {
        wellnessScore: calculateWellnessScore(
          moodStats[0]?.avgIntensity || 0,
          journalStats[0]?.totalEntries || 0,
          meditationStats[0]?.totalMinutes || 0
        ),
        consistency: calculateConsistency(activityTrend)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching statistics' });
  }
});

// @route   DELETE /api/user/account
// @desc    Delete user account
// @access  Private
router.delete('/account', async (req, res) => {
  try {
    // Prevent guest users from deleting accounts via this route
    if (req.user.isGuest) {
      return res.status(403).json({ 
        error: 'Guest accounts are automatically deleted after 24 hours' 
      });
    }

    const userId = req.user._id;

    // Delete all user data in a transaction
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Delete user and all associated data
      await Promise.all([
        User.findByIdAndDelete(userId),
        Mood.deleteMany({ user: userId }),
        Journal.deleteMany({ user: userId }),
        Meditation.deleteMany({ user: userId })
      ]);

      await session.commitTransaction();
      session.endSession();

      res.json({ 
        message: 'Account and all associated data deleted successfully' 
      });
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      throw error;
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error deleting account' });
  }
});

// Helper function to calculate streak
async function calculateStreak(userId) {
  const moods = await Mood.find({ user: userId })
    .sort({ date: -1 })
    .lean();

  let currentStreak = 0;
  let longestStreak = 0;
  let tempStreak = 0;
  let lastDate = null;

  moods.forEach((entry, index) => {
    const entryDate = new Date(entry.date);
    entryDate.setHours(0, 0, 0, 0);
    
    if (index === 0) {
      // Check if today's mood is logged
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (entryDate.getTime() === today.getTime()) {
        currentStreak = 1;
        tempStreak = 1;
      }
    } else if (lastDate) {
      // Calculate difference in days
      const diffTime = lastDate.getTime() - entryDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === 1) {
        tempStreak++;
        if (tempStreak > longestStreak) {
          longestStreak = tempStreak;
        }
        if (currentStreak === 0) {
          currentStreak = tempStreak;
        }
      } else if (diffDays > 1) {
        tempStreak = 0;
      }
    }
    
    lastDate = entryDate;
  });

  return {
    current: currentStreak,
    longest: longestStreak,
    totalDays: moods.length
  };
}

// Helper function to calculate wellness score
function calculateWellnessScore(avgMoodIntensity, journalEntries, meditationMinutes) {
  // Normalize values
  const moodScore = Math.min(avgMoodIntensity / 10, 1) * 40; // 40% weight
  const journalScore = Math.min(journalEntries / 30, 1) * 30; // 30% weight (assuming 30 entries max)
  const meditationScore = Math.min(meditationMinutes / 300, 1) * 30; // 30% weight (assuming 300 minutes max)
  
  return Math.round(moodScore + journalScore + meditationScore);
}

// Helper function to calculate consistency
function calculateConsistency(activityTrend) {
  if (activityTrend.length < 2) return 0;
  
  const activeDays = activityTrend.filter(day => day.activity > 0).length;
  const totalDays = activityTrend.length;
  
  return Math.round((activeDays / totalDays) * 100);
}

// Helper function to generate insights
function generateInsights(weeklyMoods, recentJournals) {
  const insights = [];
  
  if (weeklyMoods.length === 0) {
    insights.push("Start tracking your mood to gain insights into your emotional patterns.");
    return insights;
  }

  // Mood pattern insight
  const moodCounts = weeklyMoods.reduce((acc, mood) => {
    acc[mood.mood] = (acc[mood.mood] || 0) + 1;
    return acc;
  }, {});

  const dominantMood = Object.entries(moodCounts).reduce((a, b) => 
    a[1] > b[1] ? a : b
  )[0];

  insights.push(`Your dominant mood this week has been ${dominantMood}.`);

  // Intensity trend insight
  const avgIntensity = weeklyMoods.reduce((sum, mood) => sum + mood.intensity, 0) / weeklyMoods.length;
  if (avgIntensity > 7) {
    insights.push("You've been experiencing strong emotions this week. Remember to practice self-care.");
  } else if (avgIntensity < 4) {
    insights.push("Your emotions have been relatively mild this week. This can be a good time for reflection.");
  }

  // Journal insight
  if (recentJournals.length > 0) {
    const latestEntry = recentJournals[0];
    insights.push(`Your recent journal entry mentioned feeling ${latestEntry.mood}.`);
  }

  return insights;
}

module.exports = router;