const express = require('express');
const router = express.Router();
const Journal = require('../models/Journal');
const User = require('../models/User');
const { authMiddleware } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

// Firebase Admin (mirroring to Firestore)
const { admin, firestore } = require('../config/firebaseAdmin');

// Apply auth middleware to all routes
router.use(authMiddleware);

// @route   POST /api/journal
// @desc    Create a new journal entry
// @access  Private
router.post('/', [
  body('content')
    .notEmpty()
    .withMessage('Journal content is required')
    .trim()
    .escape(),
  body('mood')
    .optional()
    .isIn(['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired'])
], async (req, res) => {
  try {
    // Validate input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { content, mood, tags } = req.body;
    
    // Calculate word count
    const wordCount = content.trim().split(/\s+/).length;

    // Create journal entry
    const journalEntry = new Journal({
      user: req.user._id,
      content,
      mood: mood || 'neutral',
      tags: tags || [],
      wordCount
    });

    await journalEntry.save();

    // Mirror to Firestore (best-effort)
    try {
      await firestore
        .collection('users')
        .doc(String(req.user._id))
        .collection('journals')
        .doc(String(journalEntry._id))
        .set({
          title: journalEntry.title || null,
          content: journalEntry.content,
          mood: journalEntry.mood,
          tags: journalEntry.tags || [],
          wordCount: journalEntry.wordCount,
          date: journalEntry.date || admin.firestore.FieldValue.serverTimestamp(),
          mongoId: String(journalEntry._id),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
    } catch (fsErr) {
      console.warn('Firestore mirror failed for journal:', fsErr);
    }

    // Update user stats
    if (!req.user.isGuest) {
      await User.findByIdAndUpdate(req.user._id, {
        $inc: { 'stats.journalCount': 1 }
      });
    }

    res.status(201).json({
      message: 'Journal entry saved successfully',
      entry: journalEntry
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error saving journal entry' });
  }
});

// @route   GET /api/journal
// @desc    Get all journal entries for the user
// @access  Private
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10, mood, startDate, endDate } = req.query;
    
    const query = { user: req.user._id };
    
    // Apply filters
    if (mood) {
      query.mood = mood;
    }
    
    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    const entries = await Journal.find(query)
      .sort({ date: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    const total = await Journal.countDocuments(query);

    res.json({
      entries,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching journal entries' });
  }
});

// @route   GET /api/journal/:id
// @desc    Get a specific journal entry
// @access  Private
router.get('/:id', async (req, res) => {
  try {
    const entry = await Journal.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!entry) {
      return res.status(404).json({ error: 'Journal entry not found' });
    }

    res.json({ entry });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching journal entry' });
  }
});

// @route   PUT /api/journal/:id
// @desc    Update a journal entry
// @access  Private
router.put('/:id', [
  body('content').optional().trim().escape(),
  body('mood')
    .optional()
    .isIn(['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { content, mood, tags } = req.body;
    const updateData = {};

    if (content !== undefined) {
      updateData.content = content;
      updateData.wordCount = content.trim().split(/\s+/).length;
    }
    if (mood !== undefined) updateData.mood = mood;
    if (tags !== undefined) updateData.tags = tags;

    const entry = await Journal.findOneAndUpdate(
      {
        _id: req.params.id,
        user: req.user._id
      },
      updateData,
      { new: true, runValidators: true }
    );

    if (!entry) {
      return res.status(404).json({ error: 'Journal entry not found' });
    }

    // Update Firestore mirror
    try {
      await firestore
        .collection('users')
        .doc(String(req.user._id))
        .collection('journals')
        .doc(String(req.params.id))
        .set({
          ...updateData,
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    } catch (fsErr) {
      console.warn('Firestore mirror failed for journal update:', fsErr);
    }

    res.json({
      message: 'Journal entry updated successfully',
      entry
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error updating journal entry' });
  }
});

// @route   DELETE /api/journal/:id
// @desc    Delete a journal entry
// @access  Private
router.delete('/:id', async (req, res) => {
  try {
    const entry = await Journal.findOneAndDelete({
      _id: req.params.id,
      user: req.user._id
    });

    if (!entry) {
      return res.status(404).json({ error: 'Journal entry not found' });
    }

    // Remove Firestore mirror (best-effort)
    try {
      await firestore
        .collection('users')
        .doc(String(req.user._id))
        .collection('journals')
        .doc(String(req.params.id))
        .delete();
    } catch (fsErr) {
      console.warn('Firestore delete failed for journal:', fsErr);
    }

    // Update user stats
    if (!req.user.isGuest) {
      await User.findByIdAndUpdate(req.user._id, {
        $inc: { 'stats.journalCount': -1 }
      });
    }

    res.json({ message: 'Journal entry deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error deleting journal entry' });
  }
});

// @route   GET /api/journal/stats/summary
// @desc    Get journal statistics summary
// @access  Private
router.get('/stats/summary', async (req, res) => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Get mood distribution
    const moodDistribution = await Journal.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: '$mood',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    // Get entries per day for the last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const entriesByDay = await Journal.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: sevenDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$date' }
          },
          count: { $sum: 1 },
          avgWordCount: { $avg: '$wordCount' }
        }
      },
      {
        $sort: { '_id': 1 }
      }
    ]);

    // Get total word count
    const totalWordCount = await Journal.aggregate([
      {
        $match: { user: req.user._id }
      },
      {
        $group: {
          _id: null,
          totalWords: { $sum: '$wordCount' }
        }
      }
    ]);

    res.json({
      moodDistribution,
      entriesByDay,
      totalWordCount: totalWordCount[0]?.totalWords || 0,
      totalEntries: await Journal.countDocuments({ user: req.user._id })
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching journal statistics' });
  }
});

module.exports = router;