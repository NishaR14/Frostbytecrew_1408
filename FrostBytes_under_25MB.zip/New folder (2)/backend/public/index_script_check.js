// Extracted script from index.html for syntax checking

const MOOD_SCORE = {
  happy: 90,
  neutral: 60,
  sad: 40,
  stressed: 30
};

const MOOD_COLOR = {
  happy: 'linear-gradient(180deg, #fef3c7, #fb923c)',
  neutral: 'linear-gradient(180deg, #e5e7eb, #9ca3af)',
  sad: 'linear-gradient(180deg, #60a5fa, #6366f1)',
  stressed: 'linear-gradient(180deg, #c084fc, #fb7185)'
};

// Note: This file omits DOM-dependent execution; it's only for syntax validation.

function logMood(mood) {
  const today = new Date().toISOString().split('T')[0];

  const existing = appState && appState.moodHistory && appState.moodHistory.find(m => m.date === today);

  if (existing) {
    existing.mood = mood;
  } else if (appState) {
    appState.moodHistory.push({ date: today, mood });
    appState.stats.daysTracked++;
  }

  // network call example
  const userId = null;
  if (userId) {
    fetch('http://localhost:3000/api/mood', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, mood, intensity: 5 })
    }).then(res => {
      if (!res.ok) console.warn('Mood API returned', res.status);
    }).catch(err => console.warn('Mood API error', err));
  }
}
