const fs = require('fs');
const path = require('path');
(async () => {
  try {
    // Use the local proxy endpoint for testing
    const PROXY_URL = 'http://localhost:3000/api/groq';
    const GROQ_MODEL = 'llama-3.1-8b-instant';

    console.log('Using proxy endpoint:', PROXY_URL);

    const systemPrompt = 'You are a test assistant that replies with OK and echoes the user message concisely.';
    const userMessage = 'Hello, this is a short connectivity test. Reply with OK followed by the message.';

    const payload = {
      model: GROQ_MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      temperature: 0.2,
      max_tokens: 120
    };

    const resp = await fetch(PROXY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload),
      signal: (new AbortController()).signal
    });

    console.log('Status:', resp.status);
    const text = await resp.text();

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (e) {
      console.log('Response not JSON:', text.slice(0, 1000));
      process.exit(resp.ok ? 0 : 1);
    }

    // Print concise info
    console.log('Response keys:', Object.keys(parsed));
    if (parsed.choices && parsed.choices.length > 0) {
      const content = parsed.choices[0].message?.content || parsed.choices[0].text || '';
      console.log('Choice (truncated):', (content || '').toString().slice(0, 400));
    } else {
      console.log('Full response (truncated):', JSON.stringify(parsed).slice(0, 1000));
    }

    if (!resp.ok) process.exit(1);
  } catch (err) {
    console.error('Error during request:', err.message || err);
    process.exit(1);
  }
})();