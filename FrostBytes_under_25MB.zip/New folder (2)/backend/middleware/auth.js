const jwt = require('jsonwebtoken');
const User = require('../models/User');

const authMiddleware = async (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      // Check for guest mode
      if (req.headers['x-guest-mode'] === 'true') {
        req.user = { isGuest: true };
        return next();
      }
      throw new Error('No authentication token provided');
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    
    // Find user
    const user = await User.findById(decoded.userId);
    if (!user) {
      throw new Error('User not found');
    }

    // Check if user is guest (optional logic for guest users)
    if (user.isGuest && req.headers['require-auth'] === 'true') {
      throw new Error('Guest users cannot access this resource');
    }

    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    res.status(401).json({ 
      error: 'Please authenticate',
      message: error.message 
    });
  }
};

// Optional: Middleware to require authenticated (non-guest) user
const requireAuth = (req, res, next) => {
  if (req.user?.isGuest) {
    return res.status(403).json({ 
      error: 'Authentication required',
      message: 'This feature requires a registered account' 
    });
  }
  next();
};

module.exports = { authMiddleware, requireAuth };