const mongoose = require('mongoose');

const meditationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  sessionDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  duration: {
    type: Number,
    required: true, // in minutes
    min: 1,
    max: 120
  },
  type: {
    type: String,
    enum: ['breathing', 'guided', 'mindfulness', 'sleep', 'focus', 'stress-relief'],
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  beforeMood: {
    type: String,
    enum: ['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired']
  },
  afterMood: {
    type: String,
    enum: ['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired']
  },
  notes: {
    type: String,
    trim: true,
    maxlength: 500
  },
  heartRateBefore: {
    type: Number,
    min: 40,
    max: 200
  },
  heartRateAfter: {
    type: Number,
    min: 40,
    max: 200
  }
}, {
  timestamps: true
});

// Index for efficient queries
meditationSchema.index({ user: 1, sessionDate: -1 });
meditationSchema.index({ user: 1, type: 1 });

module.exports = mongoose.model('Meditation', meditationSchema);