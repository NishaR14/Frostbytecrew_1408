const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

// Initialize using GOOGLE_APPLICATION_CREDENTIALS env var if set (preferred for deployments)
if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
  try {
    admin.initializeApp(); // uses the env var-provided service account
  } catch (e) {
    console.warn('Firebase initialization warning:', e.message);
  }
} else {
  // Fallback to local service account file (config/serviceAccountKey.json)
  const keyPath = path.join(__dirname, 'serviceAccountKey.json');
  if (fs.existsSync(keyPath)) {
    const serviceAccount = require(keyPath);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
  } else {
    console.warn('No Firebase service account found at config/serviceAccountKey.json and GOOGLE_APPLICATION_CREDENTIALS not set. Firestore mirror will be disabled until credentials are provided.');
    try { admin.initializeApp(); } catch (e) { /* ignore */ }
  }
}

const firestore = admin.firestore();
module.exports = { admin, firestore };