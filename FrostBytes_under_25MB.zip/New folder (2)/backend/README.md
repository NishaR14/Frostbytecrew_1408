# Algorithm-Avengers
MoodLight is a web app with an AI chatbot designed to support users during emotional highs and lows. It includes Grok poems to offer comfort, reflection, and inspiration.

---

## Firebase (Firestore) mirror setup
This backend can mirror journal and mood entries to Google Cloud Firestore using the Firebase Admin SDK.

1. Create a Firebase project and enable **Cloud Firestore (Native mode)**.
2. In the Firebase console, go to Project Settings → Service accounts → Generate new private key. Download the JSON file.
3. Place the file at `backend/config/serviceAccountKey.json` (this path is in `.gitignore`) OR set the environment variable `GOOGLE_APPLICATION_CREDENTIALS` to the absolute path of the JSON file (preferred for production).

Example `.env` (not committed):

GOOGLE_APPLICATION_CREDENTIALS=C:\absolute\path\to\serviceAccountKey.json

5. The server will initialize Firebase Admin automatically from the env var, otherwise it will fall back to `config/serviceAccountKey.json`.

---

### Quick verification endpoints
- **POST /api/firebase/test** (requires your app auth) — writes a short test doc to Firestore under `users/{uid}/system_tests/`. Use it to verify Firestore writes after adding credentials.

Example (replace <JWT> with your auth token):

```bash
curl -X POST http://localhost:3000/api/firebase/test \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <JWT>"
```

- **POST /api/firebase/verify-id-token** — verifies a Firebase ID token (useful if you add client sign-in later). Request body: `{ "idToken": "<FIREBASE_ID_TOKEN>" }`.

Notes:
- The code mirrors create/update/delete operations for journals and moods (best-effort — if Firestore is temporarily unavailable, operations continue on MongoDB).
- If you prefer a full migration to Firestore, create a migration script (I can help write one).

